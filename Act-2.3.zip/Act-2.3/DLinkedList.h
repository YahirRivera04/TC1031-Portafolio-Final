#ifndef _DLINKEDLIST_H_
#define _DLINKEDLIST_H_
  
  #include <iostream>
  #include <stdexcept>
  
  #include "DLLNode.h"
  #include "StackLinkedList.h"

  template <class T>
  class DLinkedList {
      private:
        DLLNode<T> *head;
        DLLNode<T> *tail;
        int numElements;
        DLLNode<T> *partition(DLLNode<T> *l, DLLNode<T> *h);
        void swap (T &a, T &b); 
        void _quickSort(DLLNode<T> *l, DLLNode<T> *h);
        int verificacion(DLLNode<T> *ptr1, DLLNode<T> *ptr2);

      public:
        DLinkedList();
        ~DLinkedList();
        int getNumElements();
        void printList();
        void printLastNode();
        void addFirst(T value);
        void addLast(T value);
        bool deleteData(T value);
        bool deleteAt(int position);
        T getData(int position);
        void Iterative_quickSort();  
        
};

  template<class T>
  DLinkedList<T>::DLinkedList() {
      std::cout << "--->Creando una lista vacia" << std::endl;
      head = nullptr;
      tail = nullptr;
      numElements = 0;
  }

  template<class T>
  DLinkedList<T>::~DLinkedList() {
      std::cout << "--->Liberando memoria de la lista ligada" << std::endl;
    DLLNode<T> *p, *q;
    p = head;
    while (p != nullptr) {
      q = p->next;
      delete p;
      p = q;
    }
    head = nullptr;
    tail = nullptr;
    numElements = 0;
  }

  template<class T>
  int DLinkedList<T>::getNumElements() {
    //std::cout << "Numero de nodos " << verificacion(head, tail->prev->prev->prev) << std::endl;
    return numElements;
  }

  template<class T>
  void DLinkedList<T>::printList() {
    DLLNode<T> *ptr = head;
    while (ptr != nullptr) {
        std::cout << ptr->data.getTexto() << std::endl;
        ptr = ptr->next;
    }
    std::cout << std::endl;
  }

  template<class T>
  void DLinkedList<T>::printLastNode() {
    std::cout << tail->data << std::endl;
  }

  template<class T>
  void DLinkedList<T>::addFirst(T value) {
    DLLNode<T> *newDLLNode = new DLLNode<T>(value);
    // Si la lista está vacia
    if (head == nullptr && tail == nullptr) {
      head = newDLLNode;
      tail = newDLLNode;
    }
    else {
      newDLLNode->next = head;
      head->prev = newDLLNode;
      head = newDLLNode;
    }
    numElements++;
  }

  template<class T>
  void DLinkedList<T>::addLast(T value) {
    if (head == nullptr && tail == nullptr) {
      addFirst(value);
    }
    else {
      DLLNode<T> *newDLLNode = new DLLNode<T>(value);
      tail->next = newDLLNode;
      newDLLNode->prev = tail; 
      tail = newDLLNode;
      numElements++;
    }
  }

  template<class T>
  bool DLinkedList<T>::deleteData(T value) {
    // Si la lista esta vacia 
    if (head == nullptr && tail == nullptr) {
      return false;
    }
    else {
      DLLNode<T> *p, *q;
      p = head;
      q = nullptr;
      // buscar value en la lista
      while (p != nullptr && p->data != value) {
        q = p;
        p = p->next;
      }
      // Si no existe value en la lista
      if (p == nullptr)
        return false;
      // Si debe borrarse el primer elemento
      if (p->prev == nullptr) {
        head = p->next;
        if (head != nullptr)
          head->prev = nullptr;
      }
      else if (p->next == nullptr) { 
        // Si debe borrarse el último elemento
        q->next = nullptr;
        tail = q;
      }
      else {
        // Cualquier otro elemento entre la lista 
        q->next = p->next;
        p->next->prev = q;
      }
      delete p;
      numElements--;
      return true;
    }
  }

  template<class T>
  bool DLinkedList<T>::deleteAt(int position) {
    if (position < 0 || position >= numElements) {
      throw std::out_of_range("Indice fuera de rango");
    }
    else if (position == 0) { // Si debe borrarse el primer elemento
      DLLNode<T> *p = head;
      // Si la lista contiene solo un nodo
      if (head != nullptr && head->next == nullptr) {
        head = tail = nullptr;  
      }
      else {
        head = p->next;
        head->prev = nullptr;
      }
      delete p;
      numElements--;
      return true; 
    }
    else { // Si la lista contiene mas de un nodo
      DLLNode<T> *p = head, *q = nullptr;
      int index = 0;
      // Se busca el indice del elemento a borrar
      while (index != position) {
        q = p;
        p = p->next;
        index++;
      }
      // Si debe borrarse el último elemento
      if (p->next == nullptr) {
        q->next = nullptr;
        tail = q;
      }
      else { // Cualquier otro elemento en medio de la lista 
        q->next = p->next;
        p->next->prev = q;
      }
      delete p;
      numElements--;
      return true;
    }
  }

//Link: https://www.geeksforgeeks.org/iterative-quick-sort/
  template<class T>
  T DLinkedList<T>::getData(int position) {
    T tmp = {};
    if (position < 0 || position > numElements) {
      throw std::out_of_range("Indice fuera de rango");
    }
    else {
      if (position == 0)
        return head->data;
      DLLNode<T> *p = head;
      int index = 0;
      while (p != nullptr) {
        if (index == position)
          return p->data;
        index++;
        p = p->next;
      }
      return tmp;
    }
  }


//Link: https://www.geeksforgeeks.org/iterative-quick-sort/
template<class T>
void DLinkedList<T>::swap(T &a, T &b){ 
  T t = a; a = b; b = t; 
};

//Link: https://www.geeksforgeeks.org/iterative-quick-sort/
template<class T>
DLLNode<T> * DLinkedList<T>::partition(DLLNode<T> *l, DLLNode<T> *h) {
    if(h != nullptr && l != h && l != h->next) {
        // set pivot as h element
        T x = h->data;
        // similar to i = l-1 for array implementation
        DLLNode<T> *i = l->prev;
        // Similar to "for (int j = l; j <= h- 1; j++)"
        for (DLLNode<T> *j = l; j != h; j = j->next){
            if (j->data <= x){
                // Similar to i++ for array
                i = (i == nullptr)? l : i->next;
                swap((i->data), (j->data));
            }
        }
        i = (i == nullptr)? l : i->next; // Similar to i++
        swap((i->data), (h->data));
        //std::cout << "pivote es: " << i->data.getTexto() << std::endl;
        return i;
    }
    else {
      return nullptr;
    }
}

template<class T>
int DLinkedList<T>::verificacion(DLLNode<T> *inicio, DLLNode<T> *fin) {
    int length = -1;
    DLLNode<T> *p = inicio;
    if (inicio != nullptr && fin != nullptr) { 
      length = 1;
      while (p != nullptr) {
        if (p == fin)
          break;
        p = p->next;
        length++;
      }
    }
    return length;
}

//Esta función (así como swap y partition) fueron adaptados de un programa encontrado Geeks for geeks
//Link: https://www.geeksforgeeks.org/iterative-quick-sort/
template <class T>
void DLinkedList<T>::Iterative_quickSort(){
  //Creamos un apuntador l y h que van a head y tail respectivamente 
  DLLNode<T> *l, *h;
  l = head;
  h = tail;
  
  //Creamos un stack de apuntadores a objetos DLLNode<T>
  StackLinkedList<DLLNode<T>*> stack;
  
  // Pushea los valores iniciales de l y h
  stack.push(l);
  stack.push(h);
  
  // Seguiremos haciendo pops mientras el stack no este vacío
  while (!stack.isEmpty()) { 
    // De los apuntadores obtenemos el Top de nuestro stack y 
    // hacemos un Pop (que los saca del stack) a h and l
    // El orden aquí es importante, recordar lo de los platos-> ¿Qué plato sacas primero cuando los apilas?
    h = stack.getTop();//Por eso primero se hace con el h que es el que esta apuntando a Tail 
    stack.pop();
    l = stack.getTop();
    stack.pop();
    
    // Set pivot element at its correct position
    // in sorted array
    DLLNode<T> *p = partition(l, h);
    if (p != nullptr) {
        // Si hay elementos en el lado izquiedo del pivote,
        // les hacemos un push al lado izquierdo del pivote (p->prev)
        if (verificacion(l, p->prev) >= 2) { // hacer un método para contar el num de nodos entre dos apuntadores
            stack.push(l);
            stack.push(p->prev);
       
         } 
         // Si hay elementos en el lado derecho del pivote,
        // les hacemos un push al lado derecho del pivote (p->next)
         if (verificacion(p->next, h) >= 2) {
             stack.push(p->next);
             stack.push(h);
         }
     }
   }
}



#endif // _DLINKEDLIST_H_